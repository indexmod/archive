---
title: Wolfgang Amadeus Mozart
date: 1756-01-27 00:00:00 -0700
enddate: 1791-12-05 00:00:00 -0700
---

![](https://upload.wikimedia.org/wikipedia/commons/thumb/4/47/Croce-Mozart-Detail.jpg/185px-Croce-Mozart-Detail.jpg)

Wolfgang Amadeus Mozart, baptised as Johannes Chrysostomus Wolfgangus Theophilus Mozart, was a prolific and influential composer of the Classical era.

[Source: Wikipedia](https://en.wikipedia.org/wiki/Wolfgang_Amadeus_Mozart)