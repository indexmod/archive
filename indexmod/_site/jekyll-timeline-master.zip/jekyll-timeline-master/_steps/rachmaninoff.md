---
title: Sergei Rachmaninoff
date: 1873-04-01 00:00:00 -0700
enddate: 1943-03-28 00:00:00 -0700
---

![](https://upload.wikimedia.org/wikipedia/commons/thumb/b/be/Sergei_Rachmaninoff_cph.3a40575.jpg/128px-Sergei_Rachmaninoff_cph.3a40575.jpg)

Sergei Vasilievich Rachmaninoff was a Russian virtuoso pianist, composer, and conductor of the late-Romantic period, some of whose works are among the most popular in the classical repertoire.

[Source: Wikipedia](https://en.wikipedia.org/wiki/Sergei_Rachmaninoff)